#ifndef MXMATH_INCLUDED // -*- C++ -*-
#define MXMATH_INCLUDED
#if !defined(__GNUC__)
#  pragma once
#endif

/************************************************************************

  Standard math include file for the MixKit library.

  Copyright (C) 1998 Michael Garland.  See "COPYING.txt" for details.
  
  $Id: MxMath.h,v 1.1.1.1 2004/10/25 21:02:10 annao Exp $

 ************************************************************************/


// MXMATH_INCLUDED
#endif
