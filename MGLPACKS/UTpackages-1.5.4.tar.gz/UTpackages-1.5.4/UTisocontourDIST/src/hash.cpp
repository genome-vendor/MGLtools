/*****************************************************************************\
 *
 * hash.cc -- a simple hash table
 *
 *
 * Author:      Fausto Bernardini (fxb@cs.purdue.edu)
 *
 * Created:	Jan 26, 1996
 *
\*****************************************************************************/

// $Id: hash.cpp,v 1.1.1.1 2004/06/16 19:46:53 annao Exp $

#include "hash.h"

