#ifndef _PC_IO_H
#define _PC_IO_H

#include <stdio.h>

size_t getFloat(float *, size_t, FILE *);
size_t getInt(int *, size_t, FILE *);
size_t getShort(short *, size_t, FILE *);
size_t putFloat(float*,size_t,FILE*);





#endif
