#
# $Header: /opt/cvs/python/packages/share1.5/ViewerFramework/__init__.py,v 1.15.2.1 2008/12/04 18:57:22 annao Exp $
#
# $Id: __init__.py,v 1.15.2.1 2008/12/04 18:57:22 annao Exp $
#


FlagCheck = 1
CRITICAL_DEPENDENCIES = ['DejaVu', 'mglutil','Pmw', 'numpy', 'opengltk', 'Support']
NONCRITICAL_DEPENDENCIES = ['Vision','PIL', 'scenario', 'Volume', 'UTpackages']
