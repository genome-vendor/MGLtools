#__init__.py

FlagCheck=1
CRITICAL_DEPENDENCIES = ['numpy', 'mglutil']
NONCRITICAL_DEPENDENCIES = [ 'meshlib', 'MolKit', 'opengltk', 'ViewerFramework', 'Pmw', 'PIL', 'CCV', 'omniORB', 'Pmv', 'UTpackages', 'vlilib', 'NetworkEditor', 'bhtree', 'Vision', 'QSlimLib']
