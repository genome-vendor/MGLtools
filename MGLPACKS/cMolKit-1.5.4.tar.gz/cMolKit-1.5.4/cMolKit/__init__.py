#init of mglutilc module
