#
# copyright_notice
#

#__all__ = ()
CRITICAL_DEPENDENCIES = ['Numeric']
NONCRITICAL_DEPENDENCIES = ['mglutil']
